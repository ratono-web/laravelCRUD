<?php $__env->startSection('content'); ?>
 
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <title>Data Alumni</title>
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    </head>
    <body>
    <div class="container">
        <div class="row">
            <div class="col-md-10">
                <h3> Daftar Alumni Prodi DIV Teknik Informatika Poltek Harber</h3>
            </div>
            <div class="col-sm-2">
                <a class="btn btn-success" href="<?php echo e(route('mahasiswa.create')); ?>"> Tambah Alumni </a>
            </div>
        </div> 
        <br>

    <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>        
        </div>
    <?php endif; ?>

    <table class="table table-striped">
      <thead>
        <tr>
            <th width="40px"><b>No.</b></th>
            <th width="180px">Nama Mahasiswa</th>
            <th width="100px">NIM</th>
            <th width="100px">Angkatan</th>
            <th >Judul Skripsi</th>
            <th width="210px">Action</th>
        </tr>
      </thead>
        <?php $__currentLoopData = $mahasiswas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mahasiswa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
            <tr>
                <td><b><?php echo e(++$i); ?>.<b></td>
                <td><?php echo e($mahasiswa->namaMahasiswa); ?></td>
                <td><?php echo e($mahasiswa->nimMahasiswa); ?></td>
                <td align="center"><?php echo e($mahasiswa->angkatanMahasiswa); ?></td>
                <td><?php echo e($mahasiswa->judulskripsiMahasiswa); ?></td>
                <td>
                    <form action="<?php echo e(route('mahasiswa.destroy',$mahasiswa->id)); ?>" method="post">
                    <a class="btn btn-sm btn-success" href="<?php echo e(route('mahasiswa.show', $mahasiswa->id)); ?>">Show</a>
                    <a class="btn btn-sm btn-warning" href="<?php echo e(route('mahasiswa.edit', $mahasiswa->id)); ?>">Edit</a>
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="btn btn-sm btn-danger">Delete</button>
                    </form>    
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>

    <?php echo $mahasiswas->links(); ?>

    </div>
    </body>

</html>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>